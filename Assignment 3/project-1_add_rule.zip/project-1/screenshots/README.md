This directory will eventually contain the screenshots requested by the
assignment specification. Put your screenshots in a subdirectory for each part
of the project (`part1/`, `part2/`, etc.).
