# CSEP-561 Project 1

This directory contains starter and support code for project 1.

You may want to version control this file for your team and update this readme file with your own information.

For details of the project itself, see [the Project 1 page of the course website](https://courses.cs.washington.edu/courses/csep561/22sp/projects/project1).
