#!/bin/bash

python3 200010004.py -N 8 -B 4 -p 0.5 -queue INQ -K 0.6 -out output.txt -T 10000